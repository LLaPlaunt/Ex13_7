package ex13_7;

public enum Circle {
	;

	double getCenterX() {
		// TODO Auto-generated method stub
		return 0;
	}

	double getCenterY() {
		// TODO Auto-generated method stub
		return 0;
	}

	double getRadius() {
		// TODO Auto-generated method stub
		return 0;
	}

}
