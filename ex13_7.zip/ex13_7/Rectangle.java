package ex13_7;

public enum Rectangle {
	;

	double getX() {
		// TODO Auto-generated method stub
		return 0;
	}

	double getY() {
		// TODO Auto-generated method stub
		return 0;
	}

	double getWidth() {
		// TODO Auto-generated method stub
		return 0;
	}

	double getHeight() {
		// TODO Auto-generated method stub
		return 0;
	}

	Object getBoundsInLocal() {
		// TODO Auto-generated method stub
		return null;
	}

	boolean intersects(Object boundsInLocal) {
		// TODO Auto-generated method stub
		return false;
	}

}
