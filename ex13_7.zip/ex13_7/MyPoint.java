package ex13_7;

public enum MyPoint {
	x, y
	;

	double distance(double x, double y) {
		// TODO Auto-generated method stub
		return 0;
	}

}
